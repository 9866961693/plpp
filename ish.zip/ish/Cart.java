package ishu;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Cart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:/Users/natyam/Desktop/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		 driver.get("http://demo.opencart.com");	
		 Thread.sleep(1000);
			
		    System.out.println("Execution is stopped for 10 seconds");
		    //verifying the title
			boolean title=driver.getTitle().contains("Your Store");
			driver.findElement(By.xpath("//*[@id='content']/div[2]/div[3]/div/div[2]/h4/a")).click();
			driver.findElement(By.xpath("//*[@id='input-option218']/div[2]/label/input")).click();
			driver.findElement(By.xpath("//*[@id='input-option223']/div[3]/label/input")).click();
			driver.findElement(By.xpath("//*[@id='input-option223']/div[4]/label/input")).click();
			
			driver.findElement(By.xpath("//input[@name='option[208]']")).clear();
			driver.findElement(By.xpath("//input[@name='option[208]']")).sendKeys("Apple cinema 30");
			
			/*WebElement element= driver.findElement(By.name("option[222]"));
			element.sendKeys("C:\Users\Easy\Desktop\testfile.txt");*/
			
			Select colour=new Select(driver.findElement(By.name("option[217]")));
			colour.selectByValue("3");
			
			driver.findElement(By.name("option[209]")).sendKeys("Product will be exchanged or not");
			driver.findElement(By.id("button-cart")).click();
			
			driver.findElement(By.xpath(".//*[@id='input-option219']")).clear();
			driver.findElement(By.xpath(".//*[@id='input-option219']")).sendKeys("2018-07-28");
			
			driver.findElement(By.xpath(".//*[@id='input-option221']")).clear();
			driver.findElement(By.xpath(".//*[@id='input-option221']")).sendKeys("2:07");
		
			driver.findElement(By.xpath(".//*[@id='input-option220']")).clear();
			driver.findElement(By.xpath(".//*[@id='input-option220']")).sendKeys("2018-07-28 2:07");
			
			driver.findElement(By.name("quantity")).clear();
			driver.findElement(By.name("quantity")).sendKeys("3");
		
			
			driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
			driver.findElement(By.name("search")).sendKeys("iMac");
			
			driver.findElement(By.xpath(".//*[@id='search']/span/button")).click();
			
			driver.findElement(By.xpath(".//*[@id='content']/div[3]/div/div/div[1]/a/img")).click();
			Thread.sleep(70);
			driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[1]/strong")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath(".//*[@id='accordion']/div[1]/div[1]/h4/a")).click();
			Thread.sleep(70);
			driver.findElement(By.xpath(".//*[@id='input-coupon']")).sendKeys("123abc");
			Thread.sleep(70);
			driver.findElement(By.xpath(".//*[@id='button-coupon']")).click();
			Thread.sleep(70);
			driver.findElement(By.xpath(".//*[@id='accordion']/div[3]/div[1]/h4/a")).click();
			Thread.sleep(70);
			driver.findElement(By.xpath(".//*[@id='input-voucher']")).sendKeys("5E96D");
			Thread.sleep(70);
			driver.findElement(By.xpath(".//*[@id='button-voucher']")).click();
			driver.findElement(By.xpath(".//*[@id='accordion']/div[2]/div[1]/h4/a")).click();
			
			
			
	}

}
